=======
License
=======

.. literalinclude:: ../../LICENSE.txt
